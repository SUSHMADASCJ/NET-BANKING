<div class="footer" style="margin-bottom: 0px;">    
    <img src="images/sbi branch.jpg" style="float:left; z-index: 4; position: absolute;" height="200">
    <div style="height:100px; float:left; width:90em; margin-top: 100px; margin-left: 120px;text-align: center; z-index: 3; position: absolute;" class="mainbox">
        <h1 style="font-size:2em; font-family: 'Kaushan Script'; color:#990099;">State Bank Of India</h1>
        <h3 style="font-size:1.5em; font-family: 'Kaushan Script'; color:#ff33ff;">.......your right partner</h3>
        <p style="font-size: 22px; font-family:'Berkshire Swash',cursive; color:orange;"><marquee direction="left" onMouseOver="this.stop()" onMouseOut="this.start()">Net Banking System-A State Bank Of India Service</marquee> </p>
    </div>
    <img src="images/sbi card.jpg" style=" z-index: 4; float: right; position: absolute; margin-left:99em;" height="200">
    
</div>